
public class Parent {
	
	public static int print() {
		
		return 2*2;
		
	}

}
