import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

class Student {
	int id;
	String name;
	int age;

	public Student(int id, String name, int age) {
		this.id = id;
		this.name = name;
		this.age = age;
	}
}

public class Java8Collectors {

	public static void main(String[] args) {

		//1. Java � Stream Collectors groupingBy and counting Example
		List<String> names = Arrays.asList("Jon", "Ajeet", "Steve", "Ajeet", "Jon", "Ajeet");

		Map<String, Long> map = names.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		System.out.println(map);
		
		//2. Java � Stream Collectors example of fetching data as List
		List<Student> studentlist = new ArrayList<Student>();   
	      //Adding Students      
	      studentlist.add(new Student(11,"Jon",22));      
	      studentlist.add(new Student(22,"Steve",18));        
	      studentlist.add(new Student(33,"Lucy",22));        
	      studentlist.add(new Student(44,"Sansa",23));         
	      studentlist.add(new Student(55,"Maggie",18));                  
	      //Fetching student names as List       
	      List<String> names1 = studentlist.stream() 
	                                   .map(n->n.name) 
	                                   .collect(Collectors.toList());
	      
	      List<Integer> age = studentlist.stream() 
                  .map(n->n.age) 
                  .collect(Collectors.toList());
	      
	      System.out.println(names1+" - "+age);
	      
	      //3. Java Collectors Example � Collecting Data as Set
	      List<Student> studentlist1 = new ArrayList<Student>();       
	      //Adding Students        
	      studentlist1.add(new Student(11,"Jon",22));         
	      studentlist1.add(new Student(22,"Steve",18));         
	      studentlist1.add(new Student(33,"Lucy",22));         
	      studentlist1.add(new Student(44,"Sansa",23));         
	      studentlist1.add(new Student(55,"Maggie",18));                  
	      //Fetching student data as a Set       
	      Set<Student> students = studentlist1.stream()
	                           .filter(n-> n.id>22)
	                           .collect(Collectors.toSet());
	      //Iterating Set       
	      for(Student stu : students) { 
	         System.out.println(stu.id+" "+stu.name+" "+stu.age); 
	      } 
	      
	      students.forEach(s-> System.out.println("Name is -> "+s.name + ", Id is -> " +s.id+", Age is -> "+s.age));
	      
	      //4. Java Collectors Example � Getting the average age of students using averagingInt() method
	      //Getting the average Age 
	      Double avgAge = studentlist.stream()   
	          .collect(Collectors.averagingInt(s->s.age));  
	      System.out.println("Average Age of Students is: "+avgAge);

	}
}
