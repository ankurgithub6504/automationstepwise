package altimetrik.design.pattern.singleton;

public class SingletonDemo {

	public static void main(String[] args) {

		// illegal construct
		// Compile Time Error: The constructor SingleObject() is not visible
		// SingleObject object = new SingleObject();

		// Get the only object available
		SingletonEarlyInitialization earlyObject = SingletonEarlyInitialization.getInstance();
		SingletonLazyInitialization lazyObject = SingletonLazyInitialization.getInstanceByLazy();

		// show the message
		earlyObject.showMessage();
		lazyObject.showMessage();

	}

}
