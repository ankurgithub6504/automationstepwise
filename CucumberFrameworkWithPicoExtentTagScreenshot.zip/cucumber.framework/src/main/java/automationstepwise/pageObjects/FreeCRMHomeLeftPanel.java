package automationstepwise.pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FreeCRMHomeLeftPanel {
	
	public FreeCRMHomeLeftPanel(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using = "//div[@id='main-nav']/a")
	private List<WebElement> allLeftLinks;
	
	public int getAllLinksCount() {
		return allLeftLinks.size();
	}
	
	public List<WebElement> getAllLinks(){
		return allLeftLinks;
	}

}
