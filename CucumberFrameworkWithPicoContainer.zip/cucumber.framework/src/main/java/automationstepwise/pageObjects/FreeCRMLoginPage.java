package automationstepwise.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FreeCRMLoginPage {
	
	public FreeCRMLoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using="//input[@name='email']")
	private WebElement emailInputBox;
	
	@FindBy(how = How.XPATH, using="//input[@name='password']")
	private WebElement passwordInputBox;
	
	@FindBy(how = How.XPATH, using="//div[contains(text(),'Login')]")
	private WebElement loginButton;
	
	public void enterEmailIntoEmailInputBox(String email) {
		emailInputBox.clear();
		emailInputBox.sendKeys(email);
	}
	
	public void enterPasswordIntoPasswordInputBox(String password) {
		passwordInputBox.clear();
		passwordInputBox.sendKeys(password);
	}
	
	public void clickOnLogin() {
		loginButton.click();
	}
	
	public WebElement getEmailInputWebElement() {
		return emailInputBox;
	}
	
	public WebElement getPasswordInputWebElement() {
		return passwordInputBox;
	}
	
	public WebElement getLoginButtonWebElement() {
		return loginButton;
	}

}
