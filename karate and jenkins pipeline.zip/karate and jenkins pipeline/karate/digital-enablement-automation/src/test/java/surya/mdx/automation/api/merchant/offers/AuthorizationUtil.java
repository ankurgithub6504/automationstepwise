package surya.mdx.automation.api.merchant.offers;


import java.net.URI;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;

import com.mastercard.developer.oauth.OAuth;
import com.mastercard.developer.utils.AuthenticationUtils;

public class AuthorizationUtil {
	public static String oauth(String url, String method, String payload) throws Exception {

		PrivateKey signingKey = AuthenticationUtils.loadSigningKey("C:\\UtilityTestP12\\Utility_Test-sandbox.p12",
				"keyalias", "keystorepassword");
		URI uri = URI.create(url);
		Charset charset = StandardCharsets.UTF_8;
		return OAuth.getAuthorizationHeader(uri, method, payload, charset,
				"S_CqYnVXzQ8fSUkjwHF7UTo4Q5hlaWJjP5Qa6_nP11fdeb1f!177bb80e9cb947d6bddf58a5e67f38320000000000000000",
				signingKey);
	}

	public static String oauthStage(String url, String method, String payload) throws Exception {

		PrivateKey signingKey = AuthenticationUtils.loadSigningKey(
				System.getProperty("user.dir")+"/resources/AMO-Stage-Test-sandbox.p12", "keyalias", "keystorepassword");
		URI uri = URI.create(url);
		Charset charset = StandardCharsets.UTF_8;
		return OAuth.getAuthorizationHeader(uri, method, payload, charset,
				"2GbXKdF7f6MypeRcU4FDOCFMevntivdohDgrT-iG1c107f9e!cc7f5dd3ee704160a96a29083cb9ce570000000000000000",
				signingKey);
	}

	public static void main(String[] args) throws Exception {
		System.out.println(oauthStage("https://stage.api.mastercard.com/de/merchantoffers/offers?latitude=18.5513784&longitude=73.8882395&radius=7000&offset=0&limit=20&category=201811010002&product_type=MWE", "GET", ""));
	}
}

