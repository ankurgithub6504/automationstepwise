package automationstepwise.stepDefinitions;

import automationstepwise.cucumber.TestContext;
import automationstepwise.pageObjects.FreeCRMHomePage;
import cucumber.api.java.en.Then;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class FreeCRMHomeTest {
	TestContext testContext;
	private FreeCRMHomePage fCRMHomePage;
	
	public FreeCRMHomeTest(TestContext context) {
		this.testContext = context;
		fCRMHomePage = testContext.getPageObjectManager().getFreeCRMHomePage();
	}
	
	@Then("^verify \"([^\"]*)\" as user name$")
	public void verify_as_user_name(String arg1) throws Throwable {
	    assertThat(fCRMHomePage.getUserNameDisplayWebElement().isDisplayed(), is(true));
	    assertThat(fCRMHomePage.getUserName(), is("ankur dubey"));
	}

}
