package automationstepwise.enums;

public enum DriverType {
	
	FIREFOX,
	CHROME,
	INTERNETEXPLORER,
	SAFARI,
	MSEDGE

}
