package automationstepwise.enums;

public enum Context {

	PRODUCT_NAME,
	USER_NAME,
	EMAIL,
	PASSWORD
	
}
