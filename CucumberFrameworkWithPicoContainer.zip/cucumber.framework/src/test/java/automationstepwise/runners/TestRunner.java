package automationstepwise.runners;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/automationstepwise/features", glue = {
		"automationstepwise/stepDefinitions" }, plugin = {
				"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html" },
		// plugin = { "pretty","html:target/cucumber-reports" },
		monochrome = true, dryRun = false)
public class TestRunner {
	
}
