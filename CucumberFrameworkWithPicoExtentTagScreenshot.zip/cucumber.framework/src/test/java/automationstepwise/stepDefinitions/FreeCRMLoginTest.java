package automationstepwise.stepDefinitions;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import automationstepwise.cucumber.ScenarioContext;
import automationstepwise.cucumber.TestContext;
import automationstepwise.enums.Context;
import automationstepwise.pageObjects.FreeCRMLoginPage;
import cucumber.api.java.en.Then;

public class FreeCRMLoginTest {
	FreeCRMLoginPage fCRMLoginPage;
	TestContext testContext;
	//ScenarioContext scenarioContext;
	
	public FreeCRMLoginTest(TestContext context) {
		this.testContext = context;
		fCRMLoginPage = testContext.getPageObjectManager().getFreeCRMLoginPage();
		//scenarioContext = testContext.getScenarioContext();
		
	}
	
	@Then("^verify email and password input boxes are there$")
	public void verify_email_and_password_input_boxes_are_there() throws Throwable {
	    assertThat(fCRMLoginPage.getEmailInputWebElement().isDisplayed(), is(true));
	    assertThat(fCRMLoginPage.getPasswordInputWebElement().isDisplayed(), is(true));
	}

	@Then("^verify login to crm button is enabled$")
	public void verify_login_to_crm_button_is_enabled() throws Throwable {
		assertThat(fCRMLoginPage.getLoginButtonWebElement().getText(), is("Login"));
		assertThat(fCRMLoginPage.getLoginButtonWebElement().isEnabled(), is(true));
	}
	
	@Then("^login with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void login_with(String email, String password) throws Throwable {
		fCRMLoginPage.enterEmailIntoEmailInputBox(email);
		fCRMLoginPage.enterPasswordIntoPasswordInputBox(password);
		
		//setting scenarioContext for email and password information, so that it could be used in other steps, here it is on FreeCRMHomeTest
		testContext.getScenarioContext().setContext(Context.EMAIL, email);
		testContext.getScenarioContext().setContext(Context.PASSWORD, password);
		
		fCRMLoginPage.clickOnLogin();
	}

}
