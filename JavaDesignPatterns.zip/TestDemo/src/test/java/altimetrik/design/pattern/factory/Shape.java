package altimetrik.design.pattern.factory;

public interface Shape {
	void draw();
}
