package altimetrik.thread.practice;

public class MyClass implements Runnable {
	
	public void run() {
		System.out.println("MyClass running - Implements Runnable");
	}
	
}