function(){
	
	var env = karate.env;
	
	if(!env){
		env = 'dev';
	}
	
	var config = {
			baseUrl: 'https://stage.api.mastercard.com/de/merchantoffers',
			zomatoUrl: 'https://developers.zomato.com/api/v2.1/'
	};
	
	karate.configure('ssl', true);
	
	return config;
	
}