package automationstepwise.managers;

import org.openqa.selenium.WebDriver;

import automationstepwise.pageObjects.FreeCRMHomePage;
import automationstepwise.pageObjects.FreeCRMLandingPage;
import automationstepwise.pageObjects.FreeCRMLoginPage;

public class PageObjectManager {
	
	private WebDriver driver;
	private FreeCRMLandingPage fCRMLPage;
	private FreeCRMLoginPage fCRMLoginPage;
	private FreeCRMHomePage fCRMHomePage;
	
	public PageObjectManager(WebDriver driver) {
		this.driver = driver;
	}
	
	public FreeCRMLandingPage getFreeCRMLandingPage() {
		return (fCRMLPage == null) ? new FreeCRMLandingPage(driver) : fCRMLPage;
	}
	
	public FreeCRMLoginPage getFreeCRMLoginPage() {
		return (fCRMLoginPage == null) ? new FreeCRMLoginPage(driver) : fCRMLoginPage;
	}
	
	public FreeCRMHomePage getFreeCRMHomePage() {
		return (fCRMHomePage == null) ? new FreeCRMHomePage(driver) : fCRMHomePage;
	}

}
