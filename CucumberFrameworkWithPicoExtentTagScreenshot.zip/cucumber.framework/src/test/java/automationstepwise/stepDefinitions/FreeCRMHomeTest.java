package automationstepwise.stepDefinitions;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebElement;

import automationstepwise.cucumber.TestContext;
import automationstepwise.enums.Context;
import automationstepwise.pageObjects.FreeCRMHomeLeftPanel;
import automationstepwise.pageObjects.FreeCRMHomePage;
import cucumber.api.java.en.Then;

public class FreeCRMHomeTest {
	TestContext testContext;
	private FreeCRMHomePage fCRMHomePage;
	private FreeCRMHomeLeftPanel fCRMLPanel;
	
	public FreeCRMHomeTest(TestContext context) {
		this.testContext = context;
		fCRMHomePage = testContext.getPageObjectManager().getFreeCRMHomePage();
		fCRMLPanel = testContext.getPageObjectManager().getFreeCRMHomeLeftPanel();
	}
	
	@Then("^verify \"([^\"]*)\" as user name$")
	public void verify_as_user_name(String userName) throws Throwable {
		//setting scenarioContext for user name, this could be used further in other steps for verification
		testContext.getScenarioContext().setContext(Context.USER_NAME, userName);
		
		//assertions
	    assertThat(fCRMHomePage.getUserNameDisplayWebElement().isDisplayed(), is(true));
	    assertThat(fCRMHomePage.getUserName(), is(userName));
	    assertThat(fCRMLPanel.getAllLinksCount(), is(12));
	    
	    //assertThat(fCRMLPanel.getAllLinks().forEach(link-> link.isEnabled()), is(true));
	    fCRMLPanel.getAllLinks().forEach(link -> assertThat(link.isEnabled(), is(true)));
	    
	    //java8 steam().filter().collect() and arrow function
	    List<WebElement> result = fCRMLPanel.getAllLinks().stream()
	    						  	.filter(link-> link.getText().equalsIgnoreCase("Cases"))
	    						  	.collect(Collectors.toList());
	
	    result.get(0).click();
	    
	    //Using the scenarioContext to get the saved data in other step i.e. on FreeCRMLoginTest
	    System.out.println("Scenario context -> " + testContext.getScenarioContext().getContext(Context.EMAIL));
	    System.out.println("Scenario context -> " + testContext.getScenarioContext().getContext(Context.PASSWORD));
	}

}
