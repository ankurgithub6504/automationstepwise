
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class Java8Test {

	public static void main(String[] args) {

		List<Integer> myList = new ArrayList<>();
		for (int i = 0; i < 100; i++)
			myList.add(i);

		// sequential stream
		Stream<Integer> sequentialStream = myList.stream();

		// parallel stream
		Stream<Integer> parallelStream = myList.parallelStream();

		// using lambda with Stream API, filter example
		Stream<Integer> highNums = parallelStream.filter(p -> p > 90);
		// using lambda in forEach
		highNums.forEach(p -> System.out.println("High Nums parallel=" + p));
		//highNums.forEach(System.out::println);

		Stream<Integer> highNumsSeq = sequentialStream.filter(p -> p > 90);
		highNumsSeq.forEach(p -> System.out.println("High Nums sequential=" + p));
		//highNumsSeq.forEach(System.out::println);
		
		//forEach
		
		 List<String> list=new ArrayList<String>();  
	       list.add("Rick");         
	       list.add("Negan");       
	       list.add("Daryl");         
	       list.add("Glenn");         
	       list.add("Carl");                
	       list.forEach(          
	           // lambda expression        
	           (names)->System.out.println(names)         
	       );
	       
	       List<String> fruits = new ArrayList<String>();
	       fruits.add("Apple");
	       fruits.add("Orange");
	       fruits.add("Banana");
	       fruits.add("Pear"); 
	       fruits.add("Mango");
	       //lambda expression in forEach Method 
	       fruits.forEach(str->System.out.println(str));
	      // fruits.forEach(System.out::println);
	       
	       Map<Integer, String> hmap = new HashMap<Integer, String>();
	       hmap.put(1, "Monkey");
	       hmap.put(2, "Dog"); 
	       hmap.put(3, "Cat");  
	       hmap.put(4, "Lion");   
	       hmap.put(5, "Tiger");   
	       hmap.put(6, "Bear");
	       /* forEach to iterate and display each key and value pair
	        * of HashMap.    
	        */  
	       hmap.forEach((key,value)->System.out.println(key+" - "+value));
	       
	       
	       List<String> names = new ArrayList<String>();
	       names.add("Maggie");
	       names.add("Michonne");
	       names.add("Rick");
	       names.add("Merle");
	       names.add("Governor");
	       names.stream() //creating stream 
	      .filter(f->f.startsWith("M")) //filtering names that starts with M 
	      .forEach(System.out::println); //displaying the stream using forEach
	       
	       
	       
	       List<String> names1 = new ArrayList<String>();
	       names1.add("Maggie"); 
	       names1.add("Michonne");
	       names1.add("Rick");
	       names1.add("Merle");
	       names1.add("Governor"); 
	       //forEach - the output would be in any order
	       System.out.println("Print using forEach");
	       names1.stream() 
	      .filter(f->f.startsWith("M"))
	      .parallel() 
	      .forEach(n->System.out.println(n)); 

	      /* forEachOrdered - the output would always be in this order: 
	       * Maggie, Michonne, Merle 
	       */ 
	      System.out.println("Print using forEachOrdered"); 
	      names1.stream()  
	      .filter(f->f.startsWith("M"))  
	      .parallel() 
	      .forEachOrdered(n->System.out.println(n));

	}

}
