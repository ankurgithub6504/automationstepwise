import java.util.Arrays;
import java.util.function.BiFunction;

//1. Method reference to an instance method of an object
@FunctionalInterface
interface MyInterface {
	void display();
}

//2. Method reference to a static method of a class
class Multiplication {
	public static int multiply(int a, int b) {
		return a * b;
	}
}

//4. Method reference to a constructor
@FunctionalInterface 
interface MyInterface1{  
    Hello display(String say);  
}  
class Hello{  
    public Hello(String say){  
        System.out.print(say);  
    }  
} 

public class Java8MethodReference {

	public void myMethod() {
		System.out.println("Instance Method");
	}

	public static void main(String[] args) {
		
		//1.
		Java8MethodReference obj = new Java8MethodReference();
		// Method reference using the object of the class
		MyInterface ref = obj::myMethod;
		// Calling the method of functional interface
		ref.display();
		
		//2.
		BiFunction<Integer, Integer, Integer> product = Multiplication::multiply;  
		int pr = product.apply(11, 5);  
		System.out.println("Product of given number is: "+pr); 
		
		//3. Method reference to an instance method of an arbitrary object of a particular type
		String[] stringArray = { "Steve", "Rick", "Aditya", "Negan", "Lucy", "Sansa", "Jon"};
		/* Method reference to an instance method of an arbitrary 
		 * object of a particular type
		 */
		Arrays.sort(stringArray, String::compareToIgnoreCase);
		for(String str: stringArray){
			System.out.println(str);
		}
		
		//4.
		//Method reference to a constructor
        MyInterface1 ref1 = Hello::new;  
        ref1.display("Hello World!");
	}

}
