package common.java.util;

public class JavaUtils {
	
	public static void verifyCategory(String propertyName) {
		System.out.println(":: In java utils ::");
		System.out.println(propertyName);
	}

}
