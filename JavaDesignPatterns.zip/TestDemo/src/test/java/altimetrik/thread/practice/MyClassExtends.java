package altimetrik.thread.practice;

public class MyClassExtends extends Thread {

	public void run() {
		System.out.println("MyClass running - Extends Thread");
	}

}
