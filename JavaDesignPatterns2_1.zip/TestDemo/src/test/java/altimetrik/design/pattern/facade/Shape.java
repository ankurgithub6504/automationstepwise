package altimetrik.design.pattern.facade;

public interface Shape {

	void draw();
	
}
