package surya.mdx.automation.api.merchant.offers;

public class JavaUtils {
	
	public static void verifyCategory(String propertyName) {
		System.out.println(":: In java utils ::");
		System.out.println(propertyName);
	}

}
