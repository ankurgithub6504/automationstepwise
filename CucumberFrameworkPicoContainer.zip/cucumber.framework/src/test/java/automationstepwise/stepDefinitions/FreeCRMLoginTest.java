package automationstepwise.stepDefinitions;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import automationstepwise.cucumber.TestContext;
import automationstepwise.pageObjects.FreeCRMLoginPage;
import cucumber.api.java.en.Then;

public class FreeCRMLoginTest {
	FreeCRMLoginPage fCRMLoginPage;
	TestContext testContext;
	
	public FreeCRMLoginTest(TestContext context) {
		this.testContext = context;
		fCRMLoginPage = testContext.getPageObjectManager().getFreeCRMLoginPage();
	}
	
	@Then("^verify email and password input boxes are there$")
	public void verify_email_and_password_input_boxes_are_there() throws Throwable {
	    assertThat(fCRMLoginPage.getEmailInputWebElement().isDisplayed(), is(true));
	    assertThat(fCRMLoginPage.getPasswordInputWebElement().isDisplayed(), is(true));
	}

	@Then("^verify login to crm button is enabled$")
	public void verify_login_to_crm_button_is_enabled() throws Throwable {
		assertThat(fCRMLoginPage.getLoginButtonWebElement().isEnabled(), is(true));
	}

	@Then("^login with email password$")
	public void login_with_email_password() throws Throwable {
		fCRMLoginPage.enterEmailIntoEmailInputBox("ankurudubey6504@gmail.com");
		fCRMLoginPage.enterPasswordIntoPasswordInputBox("BeHappy@12345");
	}

}
