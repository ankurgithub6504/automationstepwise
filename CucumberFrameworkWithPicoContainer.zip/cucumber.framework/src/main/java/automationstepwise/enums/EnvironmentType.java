package automationstepwise.enums;

public enum EnvironmentType {
	
	LOCAL,
	REMOTE,
	CLOUD

}
