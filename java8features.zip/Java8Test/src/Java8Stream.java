import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;
import java.util.stream.Stream;

public class Java8Stream {
	
	public static void main(String[] args) {
		
		List<String> names = new ArrayList<String>();
		names.add("Ajeet");
		names.add("Negan");
		names.add("Aditya");
		names.add("Steve");
		int count = 0;
		for (String str : names) {
		   if (str.length() < 6) 
			count++; 
		}
	        System.out.println("There are "+count+" strings with length less than 6");
	        
	        
	   //2.
	        
	      //Using Stream and Lambda expression
	    	long count1 = names.stream().filter(str->str.length()<6).count();
	    	System.out.println("There are "+count1+" strings with length less than 6");
	    	
	    	
	   //3.
	    	
	    	Stream.iterate(1, count2->count2+1)  
	        .filter(number->number%3==0)  
	        .limit(6)  
	        .forEach(System.out::println);
	    	
	   //4.
	   
	    	//list 1
	    	List<String> alphabets = Arrays.asList("A","B","C");
	    	//list 2
	    	List<String> names3 = Arrays.asList("Sansa","Jon","Arya");
	    		
	    	//creating two streams from the two lists and concatenating them into one
	    	Stream<String> opstream = Stream.concat(alphabets.stream(), names3.stream());
	    		
	    	//displaying the elements of the concatenated stream
	    	opstream.forEach(str->System.out.print(str+" "));
	    	
	    //5. method reference ::
	    	
	    	String[] stringArray = { "Steve", "Rick", "Aditya", "Negan", "Lucy", "Sansa", "Jon"};
	    	/* Method reference to an instance method of an arbitrary 
	    	 * object of a particular type
	    	 */
	    	Arrays.sort(stringArray, String::compareToIgnoreCase);
	    	for(String str: stringArray){
	    		System.out.println(str);
	    	}
	}

}
