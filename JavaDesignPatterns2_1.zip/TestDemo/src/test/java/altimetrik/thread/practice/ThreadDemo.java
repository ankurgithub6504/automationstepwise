package altimetrik.thread.practice;

public class ThreadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Thread t1 = new Thread(new MyClass ());
		t1.start();
		
		MyClassExtends t2 = new MyClassExtends();
		t2.start();
		
	}

}
