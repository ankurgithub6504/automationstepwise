function() { 

 var env = karate.env; // get java system property 'karate.env'
 
 var provider = karate.properties['karate.provider'];
 var SYNAPSE_SERVICE_TAGS_VALUE = karate.properties['karate.SYNAPSE_SERVICE_TAGS_VALUE'];
 
 // karate.log('karate.env system property was:', env);
  
  if (!env) {
	  
    env = 'dev'; // a custom 'intelligent' default
	
  }
 
  var config = { // base config JSON
  
    appId: 'my.app.id',
    appSecret: 'my.secret',
    baseUrl: 'https://digital-enablement-automation-stage.apps.stl.pcfstage00.mastercard.int/consume',
    eapiUrl: 'https://stage.api.mastercard.com/de/merchantoffers/offers?latitude=18.5513784&longitude=73.8882395&radius=7000&offset=0&limit=20&category=201811010002&product_type=MWE',
    eapiUrlIndonesia: 'https://stage.api.mastercard.com/de/merchantoffers/offers?latitude=-6.215371&longitude=106.838443&radius=7000&limit=20&offset=0&product_type=mwe',
   	provider:'',
    SYNAPSE_SERVICE_TAGS_VALUE:''
	
  };
  
  if(provider){
  	config.provider = provider;
  }
  if(SYNAPSE_SERVICE_TAGS_VALUE ){
  	config.SYNAPSE_SERVICE_TAGS_VALUE = SYNAPSE_SERVICE_TAGS_VALUE;
  }

  if (env == 'stage') {
	  
    config.baseUrl = 'https://digital-enablement-automation-stage.apps.stl.pcfstage00.mastercard.int/consume';
    //config.baseUrl = 'https://stage.api.mastercard.com/de/merchantoffers';
   // config.baseUrl = 'https://stage.api.mastercard.com/de/merchantoffers/offers?latitude=18.5513784&longitude=73.8882395&radius=7000&offset=0&limit=20&category=201811010002&product_type=MWE'
    
	
  } else if (env == 'e2e') {
	  
    config.baseUrl = 'https://test-consumer-synapse.apps.stl.pcfdev00.mastercard.int/consume';
	
  } else{
	  
	  config.baseUrl = 'https://test-consumer-synapse.apps.stl.pcfdev00.mastercard.int/consume';
	  
  }
     
  karate.configure('connectTimeout', 30000);
  karate.configure('readTimeout', 15000);
  karate.configure('ssl', true);
  karate.configure('cookies',null);
    
  return config;
  
}