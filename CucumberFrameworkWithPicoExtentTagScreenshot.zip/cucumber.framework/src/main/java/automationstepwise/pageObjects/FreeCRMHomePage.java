package automationstepwise.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FreeCRMHomePage {
	
	public FreeCRMHomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.XPATH, using = "//span[@class='user-display']")
	private WebElement userNameDisplay;
	
	public WebElement getUserNameDisplayWebElement() {
		return userNameDisplay;
	}
	
	public String getUserName() {
		return userNameDisplay.getText();
	}

}
