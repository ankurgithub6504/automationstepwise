package automationstepwise.stepDefinitions;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

import automationstepwise.cucumber.TestContext;
import automationstepwise.pageObjects.FreeCRMLandingPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class FreeCRMLandingTest {
	TestContext testContext;
	FreeCRMLandingPage fCRMLPage;

	public FreeCRMLandingTest(TestContext context) {
		this.testContext = context;
		fCRMLPage = testContext.getPageObjectManager().getFreeCRMLandingPage();
	}
	@Given("^browser is launched$")
	public void browser_is_launched() throws Throwable {
		System.out.println("browser_is_launched");
		//testContext.getWebDriverManager().getDriver().get(FileReaderManager.getInstance().getConfigReader().getApplicationUrl());
	}

	@Given("^free crm application is loaded on browser$")
	public void free_crm_application_is_loaded_on_browser() throws Throwable {
		System.out.println("free_crm_application_is_loaded_on_browser");
		
	}

	@Then("^verify the title$")
	public void verify_the_title() throws Throwable {
		System.out.println("verify_the_title");
		String title = testContext.getWebDriverManager().getDriver().getTitle();
		assertThat(title, containsString("Free CRM #1 cloud software"));
	}

	@Then("^verify login button is enabled$")
	public void verify_login_button_is_enabled() throws Throwable {
		System.out.println("verify_login_button_is_enabled");
		assertThat(fCRMLPage.getLoginButtonWebElement().isEnabled(), is(true));
	}
	
	@Then("^click on login button$")
	public void click_on_login_button() throws Throwable {
		fCRMLPage.clickOnLoginButton();
		String currentUrl = testContext.getWebDriverManager().getDriver().getCurrentUrl();
		assertThat(currentUrl, equalTo("https://ui.freecrm.com/"));
	}


}
