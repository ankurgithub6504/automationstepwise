package surya.mdx.automation.api.merchant.ratings;

import org.junit.runner.RunWith;

import com.intuit.karate.KarateOptions;
import com.intuit.karate.junit4.Karate;

@RunWith(Karate.class)
/*@KarateOptions(tags= {"@sanity"},features= {"classpath:surya/mdx/automation/api/merchant/ratings/merchant-ratings.feature"})*/
public class TestRatingRunner {

}
